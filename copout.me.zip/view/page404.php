<!DOCTYPE html>
<html><head>
    <meta charset="UTF-8">
    <title>Отмазка-запаска 404</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
	<div>
		<h1>PAGE 404 </h1>
	</div>  
</body></html>