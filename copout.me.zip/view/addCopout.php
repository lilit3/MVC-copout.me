<!DOCTYPE html>
<html><head>
    <meta charset="UTF-8">
    <title>Отмазка-запаска topTEN</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
	<div class = "div_cont">
		<center><h1>В процессе разработки </h1></center>
	</div>  

	<div class = "div_menu" >
		<a class = "menu" href = "/?action=aboutProject">aboutProject</a>
		<a class = "menu"  href = "/?action=topTen">topTen</a>
		<a class = "menu"  href = "/?action=addCopout">addCopout</a>
		<a class = "menu"  href = "/?action=index">index</a></span>
	</div>     
</body></html>