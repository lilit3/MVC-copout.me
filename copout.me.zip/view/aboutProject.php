<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Отмазка-запаска aboutProject</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
	<div class = "div_cont">
	<center>
		<h1><?php echo $title; ?></h1>
		<p class = "p1"><?php echo $txt; ?></p>
	</center>
	</div>  

	<div class = "div_menu" >
		<a class = "menu" href = "/?action=aboutProject">aboutProject</a>
		<a class = "menu"  href = "/?action=topTen">topTen</a>
		<a class = "menu"  href = "/?action=addCopout">addCopout</a>
		<a class = "menu"  href = "/?action=index">index</a></span>
	</div>  
</body></html>