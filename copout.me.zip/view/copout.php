<!DOCTYPE html>
    <meta charset="UTF-8">
    <title>Отмазка-запаска copout</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
	<div class = "div_cont">
		<center>
		    <h3 class = "uppercase"><?php echo $copout; ?></h3>
			<span class = "button_generate" >
				<a class= "yellow_link" href = "/?action=copout">Cгенерировать отмазку</a>
			</span>
		</center>
	</div>  

	<div class = "div_menu" >
		<a class = "menu" href = "/?action=aboutProject">aboutProject</a>
		<a class = "menu"  href = "/?action=topTen">topTen</a>
		<a class = "menu"  href = "/?action=addCopout">addCopout</a>
		<a class = "menu"  href = "/?action=index">index</a></span>
	</div>   
</body></html>